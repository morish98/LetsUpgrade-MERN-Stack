const http = require('http');
const fs = require('fs');
const url = require('url');

//reading the file

const productsString = fs.readFileSync("./products.json", "utf-8");
const products = JSON.parse(productsString);

const server = http.createServer((request, response)=>{
    // const path = request.url;

    const path = url.parse(request.url, true);

    console.log(url.parse(path));

    // default headers

    response.writeHead(200, {
      'Access-Control-Allow-Origin': '*',
      'Access-Control-Allow-Methods': 'GET, POST, PUT, DELETE, PATCH, OPTIONS',
      'Access-Control-Allow-Headers': '*',  
      'Content-Type': 'application/json'
    });

    ////////////////////////////////////////////////

    if(request.method == 'OPTIONS') {
      response.end();
    }

    if (path.pathname=='/' || path.pathname=='/products') {
      response.end(productsString);
    }

    ///////////////////////////////////////////////

    else if (path.pathname=='/product') {

      if(request.method == 'GET') {
        //product id
        const id = path.query.id;
        
        const singleData = products.find((ele)=>{
          return ele.id == id;
        }); 

      response.end(JSON.stringify(singleData));
      } //get closed-----------------

      else if(request.method == 'POST') {

        let body = '';

        request.on('data', data => body += data);      //adding data in packets
        
        request.on('end', () => {   //ending the request, when every post request has been arrived
          let product = JSON.parse(body);
          products.push(product);
          //updated file
          fs.writeFile("./products.json", JSON.stringify(products), err => {    //product added to the array of objects
            response.end(JSON.stringify({message: "Product Added"}));
          });
        });        
      } //post closed------------
 
      else if(request.method == 'PUT') {
        //product id
        const id = path.query.id;
        //product data
        let body = '';

        request.on('data', data => body += data);      //adding data in packets
        
        request.on('end', () => {   //ending the request, when every post request has been arrived
          let product = JSON.parse(body);
           
          products.forEach(ele => {
            if(ele.id == id) {
              ele.title = product.title;
              ele.type = product.type;
              ele.description = product.description;
              ele.price = product.price;
            }       
          });
 
          //updated file
          fs.writeFile("./products.json", JSON.stringify(products), err => {    //product added to the array of objects

            const updatedProduct = products.find((ele) => {
              return ele.id == id;
            });

            response.end(JSON.stringify(updatedProduct));
          });
        });

      } //put closed-----------------

      else if(request.method == 'DELETE') {

        //product id
        const id = path.query.id;

        products.forEach((ele, index) => {
          if(ele.id == id) {
            products.splice(index, 1);
          }
        });
        //updated file
        fs.writeFile("./products.json", JSON.stringify(products), err => {    //product added to the array of objects
          response.end(JSON.stringify({message: "Product Deleted"}));
        });

      }

    } //delete closed-----------------

    /////////////////////////////////////////////

    else if (path.pathname == "/updateRating") {

      if(request.method == "PUT") {

        //product id
        const id = path.query.id;
        //product data
        let body = '';

        request.on('data', data => body += data);      //adding data in packets
        
        request.on('end', () => {   //ending the request, when every post request has been arrived
          let product = JSON.parse(body);  

          products.forEach(ele => {
            if(ele.id == id) {
              ele.rating = Number(ele.rating)+Number(product.rating);
              ele.rating_count = Number(ele.rating_count)+1;
            }       
          });

          //updated file
          fs.writeFile("./products.json", JSON.stringify(products), err => {    //product added to the array of objects

            const updatedProduct = products.find((ele) => {
              return ele.id == id;
            });

            response.end(JSON.stringify(updatedProduct));
          });

        });

      } 

    }

    else  {
      response.writeHead(404, {
        "Content-Type": 'application/json'
      });
      response.end(JSON.stringify( {message: 'Not found anything in this URL'} ));
    }
  });
  
  server.listen('3000', '127.0.0.1', ()=>{
    console.log('Server is running');
  });