function validateId() {

    let id = document.getElementById("id").value;

    if(id=='') {
        document.getElementById("idError").innerText = `Should not be empty!!!`;
        return false;
    }
    if(!/[0-9]{1,}/.test(id)) {
        document.getElementById("idError").innerText = `Only numbers are accepted`;
        return false;
    }

    document.getElementById("idError").innerText = '';
    return true;

}


function validateName() {

    let name = document.getElementById("name").value;

    if(name=='') {
        document.getElementById("nameError").innerText = `Should not be empty!!!`;
        return false;
    }
    if(!/^[a-zA-Z ]{1,}$/.test(name)) {
        document.getElementById("nameError").innerText = `Only alphabets and spaces are allowed`;
        return false;
    }

    document.getElementById("nameError").innerText = '';
    return true;

}


function validateDescription() {

    let description = document.getElementById("description").value;

    if(description=='') {
        document.getElementById("descriptionError").innerText = `Should not be empty!!!`;
        return false;
    }
    if(!/^[a-zA-Z .()/]{1,}$/.test(description)) {
        document.getElementById("descriptionError").innerText = `Only alphabets . / () can be used`;
        return false;
    }

    document.getElementById("descriptionError").innerText = '';
    return true;

}


function validatePrice() {

    let price = document.getElementById("price").value;

    if(price=='') {
        document.getElementById("priceError").innerText = `Should not be empty!!!`;
        return false;
    }
    if(!/^[0-9]{1,3}$/.test(price)) {
        document.getElementById("priceError").innerText = `Price should have a number`;
        return false;
    }

    document.getElementById("priceError").innerText = '';
    return true;

}


function validateRating() {

    let rating = document.getElementById("rating").value;

    if(rating=='') {
        document.getElementById("ratingError").innerText = `Should not be empty!!!`;
        return false;
    }
    if(!/^[0-5]{1}$/.test(rating)) {
        document.getElementById("ratingError").innerText = `Only one digit from (0-5) can be used`;
        return false;
    }

    document.getElementById("ratingError").innerText = '';
    return true;

}


function validateType() {

    let type = document.getElementById("type").value;

    if(type=='') {
        document.getElementById("typeError").innerText = `Should not be empty!!!`;
        return false;
    }
    if(!/^[a-zA-Z ]{1,}$/.test(type)) {
        document.getElementById("typeError").innerText = `Only alphabets can be used`;
        return false;
    }

    document.getElementById("typeError").innerText = '';
    return true;

}

let errorcount = 0;

function validateForm() {

    if(validateId()==false) {
        errorcount++;  
    }
    
    if(validateName()==false) {
        errorcount++;
    }

    if(validatePrice()==false) {
        errorcount++;
    }

    if(validateDescription()==false) {
        errorcount++;
    }

    if(validateRating()==false) {
        errorcount++;
    }

    if(validateType()==false) {
        errorcount++;
    }

    console.log(errorcount);

    if(errorcount==0) {
    
        // creating new product
        
            let product = {};
        
            product.id = document.getElementById("id").value;
            product.title = document.getElementById("name").value;
            product.description = document.getElementById("description").value;
            product.price = document.getElementById("price").value;
            product.rating = document.getElementById("rating").value;
            product.type = document.getElementById("type").value;
        
            fetch("http://localhost:3000/product", {
                method: "POST",
                body: JSON.stringify(product),
                headers: {
                    "Content-Type": "application/json"
                }
            })
            .then(response => response.json())
            .then(data => {
        
                document.getElementById("addform").reset();
                document.getElementById("message").innerHTML =
                `<p class="alert alert-success">${data.message} Successfully!!!</p>`;
            });
    
    }

    errorcount = 0;

}